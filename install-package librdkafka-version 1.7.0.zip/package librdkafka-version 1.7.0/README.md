# ZeroNet-win
ZeroNet.exe for Windows
