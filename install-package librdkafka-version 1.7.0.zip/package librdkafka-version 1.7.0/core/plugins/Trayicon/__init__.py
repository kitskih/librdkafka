import sys

if sys.platform == 'win32':
	from . import TrayiconPlugin